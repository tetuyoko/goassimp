// GENERATED CODE - DO NOT EDIT
package routes

import "github.com/revel/revel"


type tApp struct {}
var App tApp


func (_ tApp) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.Index", args).Url
}


type tStatic struct {}
var Static tStatic


func (_ tStatic) Serve(
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.Serve", args).Url
}

func (_ tStatic) ServeModule(
		moduleName string,
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "moduleName", moduleName)
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.ServeModule", args).Url
}


type tSingle struct {}
var Single tSingle


func (_ tSingle) Upload(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Single.Upload", args).Url
}

func (_ tSingle) HandleUpload(
		avatar []byte,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "avatar", avatar)
	return revel.MainRouter.Reverse("Single.HandleUpload", args).Url
}


type tUnko struct {}
var Unko tUnko


func (_ tUnko) List(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Unko.List", args).Url
}

func (_ tUnko) Show(
		id int,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "id", id)
	return revel.MainRouter.Reverse("Unko.Show", args).Url
}

func (_ tUnko) Cancel(
		id int,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "id", id)
	return revel.MainRouter.Reverse("Unko.Cancel", args).Url
}

func (_ tUnko) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Unko.Index", args).Url
}


