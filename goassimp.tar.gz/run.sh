#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/goassimp" -importPath goassimp -srcPath "$SCRIPTPATH/src" -runMode prod
